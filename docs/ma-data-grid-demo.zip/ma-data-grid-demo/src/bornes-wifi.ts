
 export const POINTS = [{
  "datasetid": "bornes-wifi",
  "recordid": "05bd10a8c2df051bb1165c6247a93abb319e81c3",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "Place de l'H\u00f4tel de Ville",
    "geo_point_2d": [49.760024, 4.719275],
    "localisation": "H\u00d4TEL DE VILLE MEZIERES 2",
    "liaison": "Cuivre",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.719275, 49.760024]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "6a54aa196f442a3459122edb9e2204c7151367bb",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "Place de l'H\u00f4tel de Ville",
    "geo_point_2d": [49.760583, 4.719116],
    "localisation": "H\u00d4TEL DE VILLE MEZIERES 1",
    "liaison": "Mesh",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.719116, 49.760583]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "be618f989aaab142f3f95191b5c07c05ab77c57e",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "Rue Bourbon",
    "geo_point_2d": [49.772291, 4.7179],
    "localisation": "RUE BOURBON / RUE DU THEATRE",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.7179, 49.772291]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "bbbaa0d8236f516f5e3d069aee3dc953c4a7e95e",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "Rue de la R\u00e9publique",
    "geo_point_2d": [49.772472, 4.720308],
    "localisation": "RUE DE LA REPUPLIQUE / RUE DE LA PAIX",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.720308, 49.772472]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "90a8d4ac5d9bcb32ed0987856f16e7829df02c1b",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "Rue de la R\u00e9publique",
    "geo_point_2d": [49.771800999999996, 4.719841],
    "localisation": "RUE DE LA REPUPLIQUE / RUE BOURBON",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.719841, 49.771800999999996]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "e7e4d8c3054f4d6cf5cb01d44efd275bb6a6d123",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "135, rue des Paquis",
    "geo_point_2d": [49.780669, 4.719389],
    "localisation": "CENTRE AQUATIQUE Bernard ALBIN - SOLARIUM",
    "liaison": "Cuivre",
    "code_insee": "08105",
    "internet": "ADSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.719389, 49.780669]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "e4a5909be18ceb14efbd8f11abc3489e820699e2",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "18, Avenue Jean JAURES",
    "geo_point_2d": [49.770516, 4.720962],
    "localisation": "SALLE DE SPECTACLE LE FORUM",
    "liaison": "Cuivre",
    "code_insee": "08105",
    "internet": "ADSL",
    "densite": "Haute",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.720962, 49.770516]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "9b533a544e103bd74e49f9bc889e8e826e5cf171",
  "fields": {
    "emplacement": "Interieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "8, Place de la Pr\u00e9fecture",
    "geo_point_2d": [49.760029, 4.720022],
    "localisation": "BIBLIOTHEQUE PORTE NEUVE",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "ADSL",
    "densite": "Normale",
    "modele": "R310"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.720022, 49.760029]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "5295e45f02136c66d430ce0475a3bd508075393b",
  "fields": {
    "emplacement": "Interieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "8, rue Ferroul",
    "geo_point_2d": [49.747321, 4.722481],
    "localisation": "BIBLIOTHEQUE RONDE COUTURE",
    "liaison": "Cuivre",
    "code_insee": "08105",
    "internet": "ADSL",
    "densite": "Normale",
    "modele": "R310"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.722481, 49.747321]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "78096ba05f997f955abc409de05bc8816a0a8512",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "SEDAN",
    "adresse": "Place CALONNE",
    "geo_point_2d": [49.699703, 4.944316],
    "localisation": "CENTRE CULTUREL - MJC CALONNE",
    "liaison": "Fibre optique",
    "code_insee": "08409",
    "internet": "VDSL",
    "densite": "Haute",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.944316, 49.699703]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "874595b1989afa675433d5d6091e412608da4309",
  "fields": {
    "emplacement": "Interieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "Rue du Daga",
    "geo_point_2d": [49.775155, 4.719052],
    "localisation": "MARCHE COUVERT",
    "liaison": "Cuivre",
    "code_insee": "08105",
    "internet": "ADSL",
    "densite": "Haute",
    "modele": "R510"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.719052, 49.775155]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "466e4d1f4fde2068c1575d6daf0125fb9f1d056b",
  "fields": {
    "emplacement": "Interieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "Rue de la Vieille Meuse",
    "geo_point_2d": [49.757503, 4.7065529999999995],
    "localisation": "CAISSE EPARGNE ARENA 1",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "R300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.7065529999999995, 49.757503]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "a0d15fd503619458f78852dda5d7359179a8f627",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "Rue des Paquis",
    "geo_point_2d": [49.778485, 4.721052],
    "localisation": "CAMPING DU MONT OLYMPE - ACCUEIL",
    "liaison": "Mesh",
    "code_insee": "08105",
    "internet": "ADSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.721052, 49.778485]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "434279161a869fd810ce21663e8fb5e7e03a8cb8",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "SEDAN",
    "adresse": "Quai Paul Bert",
    "geo_point_2d": [49.694029, 4.938448],
    "localisation": "STADE Louis DUGAUGUEZ - TRIBUNE JOURNALISTE",
    "liaison": "Cuivre",
    "code_insee": "08409",
    "internet": "ADSL",
    "densite": "Haute",
    "modele": "T610"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.938448, 49.694029]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "b4e4bc9dca6901430d63f3947d838425f371dc7c",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "SEDAN",
    "adresse": "Place CRUSSY",
    "geo_point_2d": [49.699314, 4.946315],
    "localisation": "SALLE DE SPECTACLE MARCILLET",
    "liaison": "Fibre optique",
    "code_insee": "08409",
    "internet": "VDSL",
    "densite": "Haute",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.946315, 49.699314]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "1d2e222ee8ac4be16bc0203527bce60f73fa4d7a",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "SEDAN",
    "adresse": "Place TURENNES",
    "geo_point_2d": [49.703296, 4.943267],
    "localisation": "MAIRIE",
    "liaison": "Cuivre",
    "code_insee": "08409",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T310C"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.943267, 49.703296]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "26a4a4854cc892350d256a2bf692fd00c908ed5a",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "SEDAN",
    "adresse": "Place CRUSSY",
    "geo_point_2d": [49.700428, 4.946668],
    "localisation": "PLACE CRUSSY",
    "liaison": "Mesh",
    "code_insee": "08409",
    "internet": "VDSL",
    "densite": "Haute",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.946668, 49.700428]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "a21c6383fdadeaed1c6f962b1da9c48b7534901c",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "Place de la Gare",
    "geo_point_2d": [49.76794, 4.724742],
    "localisation": "GARE SNCF - PARVIS",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.724742, 49.76794]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "6e0dc3848b0677b920d979e8a33c10405efc8480",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "SEDAN",
    "adresse": "Grande Prairie de TORCY",
    "geo_point_2d": [49.698456, 4.937647],
    "localisation": "HALTE FUVIALE",
    "liaison": "Mesh",
    "code_insee": "08409",
    "internet": "ADSL",
    "densite": "Normale",
    "modele": "T310C"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.937647, 49.698456]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "c84b11999d3cd1dd7b2c23f97c4a7f692b9950b2",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "SEDAN",
    "adresse": "Place d'Armes",
    "geo_point_2d": [49.700703, 4.947208],
    "localisation": "PLACE D'ARMES",
    "liaison": "Fibre optique",
    "code_insee": "08409",
    "internet": "VDSL",
    "densite": "Haute",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.947208, 49.700703]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "5eaa0abb6d6c685cf9e9071ba187a908b7f0c789",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "Place Ducale",
    "geo_point_2d": [49.773304, 4.719964],
    "localisation": "PLACE DUCALE - COUR DE LA CRIEE",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Haute",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.719964, 49.773304]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "5b14d12cf2a64b69bdf6584381bc7e78806f2a2b",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "Rue des Paquis",
    "geo_point_2d": [49.777337, 4.7209129999999995],
    "localisation": "CAMPING DU MONT OLYMPE - SANITAIRES",
    "liaison": "Mesh",
    "code_insee": "08105",
    "internet": "ADSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.7209129999999995, 49.777337]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "a62b9d13d9eb0c880461032a7f6973df33fc63a6",
  "fields": {
    "emplacement": "Interieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "2, Place Jacques FELIX",
    "geo_point_2d": [49.774764, 4.724162],
    "localisation": "MEDIATHEQUE VOYELLES",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "R310"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.724162, 49.774764]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "9f55c573bb2f8286838d7233d047feb46fc93b92",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "Place Ducale",
    "geo_point_2d": [49.773004, 4.721265],
    "localisation": "PLACE DUCALE - MUSEE",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Haute",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.721265, 49.773004]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "82c60d77c7ac860660b2debc4f352e774e666326",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "Cours Briand",
    "geo_point_2d": [49.770574, 4.719361],
    "localisation": "FONTAINE CHARLES DE GONZAGUE",
    "liaison": "Mesh",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.719361, 49.770574]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "c4f97ec066c13078577ac1c6445ad86d6b9f3196",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "SEDAN",
    "adresse": "Corne de Soisson, Rue des Anciens d'Afrique du Nord",
    "geo_point_2d": [49.700386, 4.943135],
    "localisation": "MEDIATHEQUE Georges DELAW 2",
    "liaison": "Fibre optique",
    "code_insee": "08409",
    "internet": "VDSL",
    "densite": "Haute",
    "modele": "T310C"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.943135, 49.700386]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "9425ffb447804186ff5bf9141d0db43013636285",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "SEDAN",
    "adresse": "Grande Prairie de TORCY",
    "geo_point_2d": [49.698226, 4.936549],
    "localisation": "CAMPING MUNICIPAL - SANITAIRE",
    "liaison": "Mesh",
    "code_insee": "08409",
    "internet": "ADSL",
    "densite": "Normale",
    "modele": "T310C"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.936549, 49.698226]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "05c01dd22c3fc1427894fe9e12c1c20252739abf",
  "fields": {
    "emplacement": "Interieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "Rue de la Vieille Meuse",
    "geo_point_2d": [49.758152, 4.706408],
    "localisation": "PARC DES EXPOSITIONS - Hall A",
    "liaison": "Cuivre",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "R310"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.706408, 49.758152]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "44b764ae4dd46f6b225afba5ff60f07a3255c594",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "Place Winston Churchill",
    "geo_point_2d": [49.772227, 4.721443],
    "localisation": "PLACE WINSTON CHURCHILL",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.721443, 49.772227]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "7a7dfd79d9a2f53ad1aacdcf66dbfef52bece6ab",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "SEDAN",
    "adresse": "Parking des Douves",
    "geo_point_2d": [49.701367, 4.949406],
    "localisation": "CH\u00c2TEAU FORT DE SEDAN",
    "liaison": "Cuivre",
    "code_insee": "08409",
    "internet": "ADSL",
    "densite": "Haute",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.949406, 49.701367]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "935f39e705e13e8a71d69356e8fa38535bc91696",
  "fields": {
    "emplacement": "Interieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "Rue de la Vieille Meuse",
    "geo_point_2d": [49.758147, 4.706378],
    "localisation": "PARC DES EXPOSITIONS - Hall A",
    "liaison": "Cuivre",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Haute",
    "modele": "R510"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.706378, 49.758147]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "d89be4432d8787cb7e7c740cb98d3383cc0c74a9",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "SEDAN",
    "adresse": "Cour du Ch\u00e2teau",
    "geo_point_2d": [49.701471, 4.949538],
    "localisation": "CH\u00c2TEAU FORT DE SEDAN",
    "liaison": "Cuivre",
    "code_insee": "08409",
    "internet": "ADSL",
    "densite": "Haute",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.949538, 49.701471]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "7b26ad65db65d0d6231d0612ba0d3c55f9768604",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "SEDAN",
    "adresse": "Place de la Gare",
    "geo_point_2d": [49.69504, 4.930517],
    "localisation": "GARE SNCF - PARVIS",
    "liaison": "Cuivre",
    "code_insee": "08409",
    "internet": "ADSL",
    "densite": "Normale",
    "modele": "T310C"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.930517, 49.69504]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "f2b61f4ea12685277d5b9185d2e2aec77617d20d",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "Passerelle du Mont Olympe",
    "geo_point_2d": [49.776304, 4.722447],
    "localisation": "PASSERELLE DU MONT OLYMPE",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.722447, 49.776304]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "77fb68776f6b26419724e7b129e5b35efbc0c8a8",
  "fields": {
    "emplacement": "Interieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "135, rue des Paquis",
    "geo_point_2d": [49.781057, 4.719724],
    "localisation": "CENTRE AQUATIQUE Bernard ALBIN - HALL ENTREE",
    "liaison": "Cuivre",
    "code_insee": "08105",
    "internet": "ADSL",
    "densite": "Normale",
    "modele": "R300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.719724, 49.781057]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "6d68fe0a71dd06715910168ff8b7f3b3995f292e",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "Rue des Paquis",
    "geo_point_2d": [49.778146, 4.720006],
    "localisation": "CAMPING DU MONT OLYMPE - BASE NAUTIQUE",
    "liaison": "Cuivre",
    "code_insee": "08105",
    "internet": "ADSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.720006, 49.778146]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "08ec27402b640bd4bc045707bde5a3a3b3c85c2f",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "Avenue Charles BOUTET",
    "geo_point_2d": [49.774526, 4.716719],
    "localisation": "METROPOLIS - NORD EST CINEMA",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.716719, 49.774526]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "bff9d9ec552237bdadf7eed43ca985338de2ba92",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "Quai Jean Charcot",
    "geo_point_2d": [49.775521, 4.721973],
    "localisation": "MUSEE ARTHUR RIMBAUD",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.721973, 49.775521]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "6e3d9eab4e87481bacd871b0912bb2a237b2aab5",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "SEDAN",
    "adresse": "Grande Prairie de TORCY",
    "geo_point_2d": [49.698723, 4.938538],
    "localisation": "CAMPING MUNICIPAL - ACCUEIL",
    "liaison": "Cuivre",
    "code_insee": "08409",
    "internet": "ADSL",
    "densite": "Normale",
    "modele": "T310C"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.938538, 49.698723]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "d5bd39d666e4b34b26d9fabfef2e0e72720d56d6",
  "fields": {
    "emplacement": "Interieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "Rue du Th\u00e9\u00e2tre",
    "geo_point_2d": [49.773302, 4.718837],
    "localisation": "THEATRE MUNICIPAL",
    "liaison": "Cuivre",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "R310"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.718837, 49.773302]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "3d65b52cb1c31ce4d8296b6a34b454a7ac62724d",
  "fields": {
    "emplacement": "Int\u00e9rieur",
    "commune": "SEDAN",
    "adresse": "Corne de Soisson, Rue des Anciens d'Afrique du Nord",
    "geo_point_2d": [49.700499, 4.943193],
    "localisation": "MEDIATHEQUE Georges DELAW 1",
    "liaison": "Cuivre",
    "code_insee": "08409",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "H510"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.943193, 49.700499]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "b368d33b2835265a2e3397f22e08d43009b094d0",
  "fields": {
    "emplacement": "Interieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "Rue de la Vieille Meuse",
    "geo_point_2d": [49.757503, 4.70703],
    "localisation": "CAISSE EPARGNE ARENA 2",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "R300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.70703, 49.757503]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "5f0f4cf4eac41eabd5b018956c730e220d0acde7",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "adresse": "Place Lucien BAUCHART",
    "geo_point_2d": [49.747972, 4.724178],
    "localisation": "Place BAUCHART",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.724178, 49.747972]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "191a4586ccab371dfbf48dabdb0d7a2e38d4ba1b",
  "fields": {
    "emplacement": "Interieur",
    "commune": "SEDAN",
    "adresse": "Quai Paul Bert",
    "geo_point_2d": [49.693722, 4.93859],
    "localisation": "STADE Louis DUGAUGUEZ - SALLE DE PRESSE",
    "liaison": "Cuivre",
    "code_insee": "08409",
    "internet": "ADSL",
    "densite": "Normale",
    "modele": "R310"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.93859, 49.693722]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "9d37d8fa6732d37f9cd90e2400b125f30f8d2f00",
  "fields": {
    "emplacement": "Interieur",
    "commune": "SEDAN",
    "adresse": "8, Esplanade du Lac",
    "geo_point_2d": [49.69315, 4.9435009999999995],
    "localisation": "CENTRE AQUATIQUE - HALL ENTREE",
    "liaison": "Cuivre",
    "code_insee": "08409",
    "internet": "ADSL",
    "densite": "Normale",
    "modele": "R310"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.9435009999999995, 49.69315]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "42df188e00e0947ab9b10fa3c6d79e51ae07bc14",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "SEDAN",
    "adresse": "Place de la Halle",
    "geo_point_2d": [49.700045, 4.948255],
    "localisation": "PLACE DE LA HALLE",
    "liaison": "Fibre optique",
    "code_insee": "08409",
    "internet": "VDSL",
    "densite": "Haute",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.948255, 49.700045]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
},

{
  "datasetid": "bornes-wifi",
  "recordid": "05bd10a8c2df051bb1165c6247a93abb319e81c3",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Damouzy",
    "adresse": "Place de l'H\u00f4tel de Ville",
    "geo_point_2d": [49.760024, 4.719275],
    "localisation": "H\u00d4TEL DE VILLE MEZIERES 2",
    "liaison": "Cuivre",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.719275, 49.760024]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "6a54aa196f442a3459122edb9e2204c7151367bb",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Damouzy",
    "adresse": "Place de l'H\u00f4tel de Ville",
    "geo_point_2d": [49.760583, 4.719116],
    "localisation": "H\u00d4TEL DE VILLE MEZIERES 1",
    "liaison": "Mesh",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.719116, 49.760583]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "be618f989aaab142f3f95191b5c07c05ab77c57e",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Damouzy",
    "adresse": "Rue Bourbon",
    "geo_point_2d": [49.772291, 4.7179],
    "localisation": "RUE BOURBON / RUE DU THEATRE",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.7179, 49.772291]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "bbbaa0d8236f516f5e3d069aee3dc953c4a7e95e",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Damouzy",
    "adresse": "Rue de la R\u00e9publique",
    "geo_point_2d": [49.772472, 4.720308],
    "localisation": "RUE DE LA REPUPLIQUE / RUE DE LA PAIX",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.720308, 49.772472]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "90a8d4ac5d9bcb32ed0987856f16e7829df02c1b",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Damouzy",
    "adresse": "Rue de la R\u00e9publique",
    "geo_point_2d": [49.771800999999996, 4.719841],
    "localisation": "RUE DE LA REPUPLIQUE / RUE BOURBON",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.719841, 49.771800999999996]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "e7e4d8c3054f4d6cf5cb01d44efd275bb6a6d123",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Damouzy",
    "adresse": "135, rue des Paquis",
    "geo_point_2d": [49.780669, 4.719239],
    "localisation": "CENTRE AQUATIQUE Bernard ALBIN - SOLARIUM",
    "liaison": "Cuivre",
    "code_insee": "08105",
    "internet": "ADSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.719239, 49.780669]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "e4a5909be18ceb14efbd8f11abc3489e820699e2",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Damouzy",
    "adresse": "18, Avenue Jean JAURES",
    "geo_point_2d": [49.770516, 4.720962],
    "localisation": "SALLE DE SPECTACLE LE FORUM",
    "liaison": "Cuivre",
    "code_insee": "08105",
    "internet": "ADSL",
    "densite": "Haute",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.720962, 49.770516]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "9b533a544e103bd74e49f9bc889e8e826e5cf171",
  "fields": {
    "emplacement": "Interieur",
    "commune": "Damouzy",
    "adresse": "8, Place de la Pr\u00e9fecture",
    "geo_point_2d": [49.760029, 4.720022],
    "localisation": "BIBLIOTHEQUE PORTE NEUVE",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "ADSL",
    "densite": "Normale",
    "modele": "R310"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.720022, 49.760029]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "5295e45f02136c66d430ce0475a3bd508075393b",
  "fields": {
    "emplacement": "Interieur",
    "commune": "Damouzy",
    "adresse": "8, rue Ferroul",
    "geo_point_2d": [49.747321, 4.722481],
    "localisation": "BIBLIOTHEQUE RONDE COUTURE",
    "liaison": "Cuivre",
    "code_insee": "08105",
    "internet": "ADSL",
    "densite": "Normale",
    "modele": "R310"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.722481, 49.747321]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "78096ba05f997f955abc409de05bc8816a0a8512",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Nouzon",
    "adresse": "Place CALONNE",
    "geo_point_2d": [49.699703, 4.944316],
    "localisation": "CENTRE CULTUREL - MJC CALONNE",
    "liaison": "Fibre optique",
    "code_insee": "08409",
    "internet": "VDSL",
    "densite": "Haute",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.944316, 49.699703]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "874595b1989afa675433d5d6091e412608da4309",
  "fields": {
    "emplacement": "Interieur",
    "commune": "Damouzy",
    "adresse": "Rue du Daga",
    "geo_point_2d": [49.775155, 4.719052],
    "localisation": "MARCHE COUVERT",
    "liaison": "Cuivre",
    "code_insee": "08105",
    "internet": "ADSL",
    "densite": "Haute",
    "modele": "R510"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.719052, 49.775155]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "466e4d1f4fde2068c1575d6daf0125fb9f1d056b",
  "fields": {
    "emplacement": "Interieur",
    "commune": "Damouzy",
    "adresse": "Rue de la Vieille Meuse",
    "geo_point_2d": [49.757503, 4.7065529999999995],
    "localisation": "CAISSE EPARGNE ARENA 1",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "R300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.7065529999999995, 49.757503]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "a0d15fd503619458f78852dda5d7359179a8f627",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Damouzy",
    "adresse": "Rue des Paquis",
    "geo_point_2d": [49.778485, 4.721052],
    "localisation": "CAMPING DU MONT OLYMPE - ACCUEIL",
    "liaison": "Mesh",
    "code_insee": "08105",
    "internet": "ADSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.721052, 49.778485]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "434279161a869fd810ce21663e8fb5e7e03a8cb8",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Nouzon",
    "adresse": "Quai Paul Bert",
    "geo_point_2d": [49.694029, 4.923448],
    "localisation": "STADE Louis DUGAUGUEZ - TRIBUNE JOURNALISTE",
    "liaison": "Cuivre",
    "code_insee": "08409",
    "internet": "ADSL",
    "densite": "Haute",
    "modele": "T610"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.923448, 49.694029]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "b4e4bc9dca6901430d63f3947d838425f371dc7c",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Nouzon",
    "adresse": "Place CRUSSY",
    "geo_point_2d": [49.699314, 4.946315],
    "localisation": "SALLE DE SPECTACLE MARCILLET",
    "liaison": "Fibre optique",
    "code_insee": "08409",
    "internet": "VDSL",
    "densite": "Haute",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.946315, 49.699314]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "1d2e222ee8ac4be16bc0203527bce60f73fa4d7a",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Nouzon",
    "adresse": "Place TURENNES",
    "geo_point_2d": [49.703296, 4.943267],
    "localisation": "MAIRIE",
    "liaison": "Cuivre",
    "code_insee": "08409",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T310C"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.943267, 49.703296]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "26a4a4854cc892350d256a2bf692fd00c908ed5a",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Nouzon",
    "adresse": "Place CRUSSY",
    "geo_point_2d": [49.700428, 4.946668],
    "localisation": "PLACE CRUSSY",
    "liaison": "Mesh",
    "code_insee": "08409",
    "internet": "VDSL",
    "densite": "Haute",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.946668, 49.700428]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "a21c6383fdadeaed1c6f962b1da9c48b7534901c",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Damouzy",
    "adresse": "Place de la Gare",
    "geo_point_2d": [49.76794, 4.724742],
    "localisation": "GARE SNCF - PARVIS",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.724742, 49.76794]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "6e0dc3848b0677b920d979e8a33c10405efc8480",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Nouzon",
    "adresse": "Grande Prairie de TORCY",
    "geo_point_2d": [49.698456, 4.937647],
    "localisation": "HALTE FUVIALE",
    "liaison": "Mesh",
    "code_insee": "08409",
    "internet": "ADSL",
    "densite": "Normale",
    "modele": "T310C"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.937647, 49.698456]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "c84b11999d3cd1dd7b2c23f97c4a7f692b9950b2",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Nouzon",
    "adresse": "Place d'Armes",
    "geo_point_2d": [49.700703, 4.947208],
    "localisation": "PLACE D'ARMES",
    "liaison": "Fibre optique",
    "code_insee": "08409",
    "internet": "VDSL",
    "densite": "Haute",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.947208, 49.700703]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "5eaa0abb6d6c685cf9e9071ba187a908b7f0c789",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Damouzy",
    "adresse": "Place Ducale",
    "geo_point_2d": [49.773304, 4.719964],
    "localisation": "PLACE DUCALE - COUR DE LA CRIEE",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Haute",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.719964, 49.773304]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "5b14d12cf2a64b69bdf6584381bc7e78806f2a2b",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Damouzy",
    "adresse": "Rue des Paquis",
    "geo_point_2d": [49.777337, 4.7209129999999995],
    "localisation": "CAMPING DU MONT OLYMPE - SANITAIRES",
    "liaison": "Mesh",
    "code_insee": "08105",
    "internet": "ADSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.7209129999999995, 49.777337]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "a62b9d13d9eb0c880461032a7f6973df33fc63a6",
  "fields": {
    "emplacement": "Interieur",
    "commune": "Damouzy",
    "adresse": "2, Place Jacques FELIX",
    "geo_point_2d": [49.774764, 4.724162],
    "localisation": "MEDIATHEQUE VOYELLES",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "R310"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.724162, 49.774764]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "9f55c573bb2f8286838d7233d047feb46fc93b92",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Damouzy",
    "adresse": "Place Ducale",
    "geo_point_2d": [49.773004, 4.721265],
    "localisation": "PLACE DUCALE - MUSEE",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Haute",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.721265, 49.773004]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "82c60d77c7ac860660b2debc4f352e774e666326",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Damouzy",
    "adresse": "Cours Briand",
    "geo_point_2d": [49.770574, 4.719361],
    "localisation": "FONTAINE CHARLES DE GONZAGUE",
    "liaison": "Mesh",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.719361, 49.770574]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "c4f97ec066c13078577ac1c6445ad86d6b9f3196",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Nouzon",
    "adresse": "Corne de Soisson, Rue des Anciens d'Afrique du Nord",
    "geo_point_2d": [49.700386, 4.943135],
    "localisation": "MEDIATHEQUE Georges DELAW 2",
    "liaison": "Fibre optique",
    "code_insee": "08409",
    "internet": "VDSL",
    "densite": "Haute",
    "modele": "T310C"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.943135, 49.700386]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "9425ffb447804186ff5bf9141d0db43013636285",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Nouzon",
    "adresse": "Grande Prairie de TORCY",
    "geo_point_2d": [49.698226, 4.936549],
    "localisation": "CAMPING MUNICIPAL - SANITAIRE",
    "liaison": "Mesh",
    "code_insee": "08409",
    "internet": "ADSL",
    "densite": "Normale",
    "modele": "T310C"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.936549, 49.698226]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "05c01dd22c3fc1427894fe9e12c1c20252739abf",
  "fields": {
    "emplacement": "Interieur",
    "commune": "Damouzy",
    "adresse": "Rue de la Vieille Meuse",
    "geo_point_2d": [49.758152, 4.706408],
    "localisation": "PARC DES EXPOSITIONS - Hall A",
    "liaison": "Cuivre",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "R310"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.706408, 49.758152]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "44b764ae4dd46f6b225afba5ff60f07a3255c594",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Damouzy",
    "adresse": "Place Winston Churchill",
    "geo_point_2d": [49.772227, 4.721443],
    "localisation": "PLACE WINSTON CHURCHILL",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.721443, 49.772227]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "7a7dfd79d9a2f53ad1aacdcf66dbfef52bece6ab",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Nouzon",
    "adresse": "Parking des Douves",
    "geo_point_2d": [49.701367, 4.949406],
    "localisation": "CH\u00c2TEAU FORT DE Nouzon",
    "liaison": "Cuivre",
    "code_insee": "08409",
    "internet": "ADSL",
    "densite": "Haute",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.949406, 49.701367]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "935f39e705e13e8a71d69356e8fa38535bc91696",
  "fields": {
    "emplacement": "Interieur",
    "commune": "Damouzy",
    "adresse": "Rue de la Vieille Meuse",
    "geo_point_2d": [49.758147, 4.706378],
    "localisation": "PARC DES EXPOSITIONS - Hall A",
    "liaison": "Cuivre",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Haute",
    "modele": "R510"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.706378, 49.758147]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "d89be4432d8787cb7e7c740cb98d3383cc0c74a9",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Nouzon",
    "adresse": "Cour du Ch\u00e2teau",
    "geo_point_2d": [49.701471, 4.949538],
    "localisation": "CH\u00c2TEAU FORT DE Nouzon",
    "liaison": "Cuivre",
    "code_insee": "08409",
    "internet": "ADSL",
    "densite": "Haute",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.949538, 49.701471]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "7b26ad65db65d0d6231d0612ba0d3c55f9768604",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Nouzon",
    "adresse": "Place de la Gare",
    "geo_point_2d": [49.69504, 4.930517],
    "localisation": "GARE SNCF - PARVIS",
    "liaison": "Cuivre",
    "code_insee": "08409",
    "internet": "ADSL",
    "densite": "Normale",
    "modele": "T310C"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.930517, 49.69504]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "f2b61f4ea12685277d5b9185d2e2aec77617d20d",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Damouzy",
    "adresse": "Passerelle du Mont Olympe",
    "geo_point_2d": [49.776304, 4.722447],
    "localisation": "PASSERELLE DU MONT OLYMPE",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.722447, 49.776304]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "77fb68776f6b26419724e7b129e5b35efbc0c8a8",
  "fields": {
    "emplacement": "Interieur",
    "commune": "Damouzy",
    "adresse": "135, rue des Paquis",
    "geo_point_2d": [49.781057, 4.719724],
    "localisation": "CENTRE AQUATIQUE Bernard ALBIN - HALL ENTREE",
    "liaison": "Cuivre",
    "code_insee": "08105",
    "internet": "ADSL",
    "densite": "Normale",
    "modele": "R300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.719724, 49.781057]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "6d68fe0a71dd06715910168ff8b7f3b3995f292e",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Damouzy",
    "adresse": "Rue des Paquis",
    "geo_point_2d": [49.778146, 4.720006],
    "localisation": "CAMPING DU MONT OLYMPE - BASE NAUTIQUE",
    "liaison": "Cuivre",
    "code_insee": "08105",
    "internet": "ADSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.720006, 49.778146]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "08ec27402b640bd4bc045707bde5a3a3b3c85c2f",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Damouzy",
    "adresse": "Avenue Charles BOUTET",
    "geo_point_2d": [49.774526, 4.716719],
    "localisation": "METROPOLIS - NORD EST CINEMA",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.716719, 49.774526]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "bff9d9ec552237bdadf7eed43ca985338de2ba92",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Damouzy",
    "adresse": "Quai Jean Charcot",
    "geo_point_2d": [49.775521, 4.721973],
    "localisation": "MUSEE ARTHUR RIMBAUD",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.721973, 49.775521]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "6e3d9eab4e87481bacd871b0912bb2a237b2aab5",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Nouzon",
    "adresse": "Grande Prairie de TORCY",
    "geo_point_2d": [49.698723, 4.923538],
    "localisation": "CAMPING MUNICIPAL - ACCUEIL",
    "liaison": "Cuivre",
    "code_insee": "08409",
    "internet": "ADSL",
    "densite": "Normale",
    "modele": "T310C"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.923538, 49.698723]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "d5bd39d666e4b34b26d9fabfef2e0e72720d56d6",
  "fields": {
    "emplacement": "Interieur",
    "commune": "Damouzy",
    "adresse": "Rue du Th\u00e9\u00e2tre",
    "geo_point_2d": [49.773302, 4.718837],
    "localisation": "THEATRE MUNICIPAL",
    "liaison": "Cuivre",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "R310"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.718837, 49.773302]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "3d65b52cb1c31ce4d8296b6a34b454a7ac62724d",
  "fields": {
    "emplacement": "Int\u00e9rieur",
    "commune": "Nouzon",
    "adresse": "Corne de Soisson, Rue des Anciens d'Afrique du Nord",
    "geo_point_2d": [49.700499, 4.943193],
    "localisation": "MEDIATHEQUE Georges DELAW 1",
    "liaison": "Cuivre",
    "code_insee": "08409",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "H510"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.943193, 49.700499]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "b368d33b2835265a2e3397f22e08d43009b094d0",
  "fields": {
    "emplacement": "Interieur",
    "commune": "Damouzy",
    "adresse": "Rue de la Vieille Meuse",
    "geo_point_2d": [49.757503, 4.70703],
    "localisation": "CAISSE EPARGNE ARENA 2",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "R300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.70703, 49.757503]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "5f0f4cf4eac41eabd5b018956c730e220d0acde7",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Damouzy",
    "adresse": "Place Lucien BAUCHART",
    "geo_point_2d": [49.747972, 4.724178],
    "localisation": "Place BAUCHART",
    "liaison": "Fibre optique",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.724178, 49.747972]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "191a4586ccab371dfbf48dabdb0d7a2e38d4ba1b",
  "fields": {
    "emplacement": "Interieur",
    "commune": "Nouzon",
    "adresse": "Quai Paul Bert",
    "geo_point_2d": [49.693722, 4.92359],
    "localisation": "STADE Louis DUGAUGUEZ - SALLE DE PRESSE",
    "liaison": "Cuivre",
    "code_insee": "08409",
    "internet": "ADSL",
    "densite": "Normale",
    "modele": "R310"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.92359, 49.693722]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "9d37d8fa6732d37f9cd90e2400b125f30f8d2f00",
  "fields": {
    "emplacement": "Interieur",
    "commune": "Nouzon",
    "adresse": "8, Esplanade du Lac",
    "geo_point_2d": [49.69315, 4.9435009999999995],
    "localisation": "CENTRE AQUATIQUE - HALL ENTREE",
    "liaison": "Cuivre",
    "code_insee": "08409",
    "internet": "ADSL",
    "densite": "Normale",
    "modele": "R310"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.9435009999999995, 49.69315]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}, {
  "datasetid": "bornes-wifi",
  "recordid": "42df188e00e0947ab9b10fa3c6d79e51ae07bc14",
  "fields": {
    "emplacement": "Exterieur",
    "commune": "Nouzon",
    "adresse": "Place de la Halle",
    "geo_point_2d": [49.700045, 4.948255],
    "localisation": "PLACE DE LA HALLE",
    "liaison": "Fibre optique",
    "code_insee": "08409",
    "internet": "VDSL",
    "densite": "Haute",
    "modele": "T300"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [4.948255, 49.700045]
  },
  "record_timestamp": "2019-05-06T22:45:36.503+02:00"
}
]
