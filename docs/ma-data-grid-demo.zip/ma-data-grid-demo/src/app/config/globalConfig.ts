

export class AppConfig {

    static API_SERVER = "https://pc-alain:981"; // "http://127.0.0.1:8080"
    
    static API_URI_AUTHENTICATION = AppConfig.API_SERVER + "/login";
    static API_URI_REFRESH_TOKEN = AppConfig.API_SERVER + "/renewToken";
    static API_URI_UPLOAD = AppConfig.API_SERVER + "/uploads";
    static API_URI_AUTHENTICATION_HEADER_FIELD = "AppAuthorizationToken"

    // Durée maximale sans activité avant la redirection vers la page d'authentification '/'
    // /!\ cette durée doit être supérieur à la durée du token fourni par l'API
    // Cf: ACCESS_TOKEN_LIFE sur l'API
    static MAX_SECOND_WITHOUT_ACTIVITY = 300;

    //static ACCESS_TOKEN_SECRET = "..."

}