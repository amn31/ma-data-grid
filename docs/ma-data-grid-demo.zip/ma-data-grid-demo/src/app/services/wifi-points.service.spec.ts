import { TestBed } from '@angular/core/testing';

import { WifiPointsService } from './wifi-points.service';

describe('WifiPointsService', () => {
  let service: WifiPointsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WifiPointsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
