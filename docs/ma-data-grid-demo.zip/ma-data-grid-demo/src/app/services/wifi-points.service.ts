import { MaFilter } from '@amn31/filter-multiple-conditions'
import { Injectable } from '@angular/core';
import { POINTS } from "../../bornes-wifi";
@Injectable({
  providedIn: 'root'
})
export class WifiPointsService {

  data = [];
  constructor() { }

  async getDistinctValues(field: string): Promise<string[]> {

    if (this.data.length == 0) {
      await this.getAllPoints().then(d => {
        
        return this.getDistinctValues(field);
      })
    }

    return new Promise((resolve, reject) => {
      setTimeout(() => {
        var v = [];
        for (var o of this.data) {
          if (!(v.find((v) => v == o[field]))) {
            v.push(o[field])
          }
        }
        resolve(v);
      }, 200);

    });

  }
  /**
   * Return array of object
   * {
      "emplacement": "Exterieur",
      "commune": "CHARLEVILLE-MEZIERES",
      "geo_point_2d": [
        49.760024,
        4.719275
      ],
      "localisation": "HÔTEL DE VILLE MEZIERES 2",
      "liaison": "<b>Cuivre</b>",
      "code_insee": "08105",
      "internet": "VDSL",
      "densite": "Normale",
      "modele": "T300",
      "address": null,
      "timestamp": "2021-01-01",
      "lat": 4.719275,
      "lng": 49.760024,
      "id": 1,
      "hasShortAddress": false
     }
   *
   * @return {*}  {Promise<any[]>}
   * @memberof WifiPointsService
   */
  getAllPoints(): Promise<any[]> {

    /*
       {
     "datasetid": "bornes-wifi",
     "recordid": "05bd10a8c2df051bb1165c6247a93abb319e81c3",
     "fields": {
       "emplacement": "Exterieur",
       "commune": "CHARLEVILLE-MEZIERES",
       "adresse": "Place de l'H\u00f4tel de Ville",
       "geo_point_2d": [49.760024, 4.719275],
       "localisation": "H\u00d4TEL DE VILLE MEZIERES 2",
       "liaison": "Cuivre",
       "code_insee": "08105",
       "internet": "VDSL",
       "densite": "Normale",
       "modele": "T300"
     },
     "geometry": {
       "type": "Point",
       "coordinates": [4.719275, 49.760024]
     },
     "record_timestamp": "2019-05-06T22:45:36.503+02:00"
     */
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        var d = [];
        
        for (let item of POINTS) {
          // Clone object
          let o = JSON.parse(JSON.stringify(item));
          o.fields['address'] = o.fields.adresse;
          if (o.fields['address']) {
            o.fields['usage'] = o.fields.adresse.length * 2;
            if (o.fields['usage'] > 100)
              o.fields['usage'] = 100;
          }
          
          o.fields['timestamp'] = new Date(new Date().getTime() - ((d.length + 1) * 3600 * 24 * 160 * 100)).toISOString().replace(/T.+/, '');
          delete o.fields['adresse'];
          o.fields['lat'] = o.geometry.coordinates[0];
          o.fields['lng'] = o.geometry.coordinates[1];
          o.fields['id'] = d.length + 1;

          o.fields['isNew'] = (o.fields['address'] && o.fields['address'].length <= 17);
          if (o.fields['address'] && o.fields['address'].length <= 13) {
            o.fields['isNew'] = null;
          }
          if (o.fields.liaison.match(/fibre/i)) {
            o.fields.liaison = 'Fibre';
          }
          if (o.fields.liaison == 'Cuivre') {
            o.fields.liaison = '<b>Cuivre</b>'
          }
          if (o.fields['address'] && o.fields['address'].length > 25) {
            o.fields['address'] = null;
            o.fields['lng'] = null;
            o.fields['lat'] = null;
          }
          if (d.length == 1) {
            delete o.fields['lng'];
            delete o.fields['address'];
            delete o.fields['liaison'];
          }
          d.push(o.fields);
        }
        this.data = d;
        resolve(d);
      }, 500);
    });

  }

/**
 *  this.wifiPointsService.getPoints({
        where: [ ['id','<',43]],
        offset: 0,
        limit: 10, 
        sort: {field: 'id', reverse: true}
      }).then(data => {
      console.log('DATA',data);
    })

    Return array of object
  * {
      "emplacement": "Exterieur",
      "commune": "CHARLEVILLE-MEZIERES",
      "geo_point_2d": [
        49.760024,
        4.719275
      ],
      "localisation": "HÔTEL DE VILLE MEZIERES 2",
      "liaison": "<b>Cuivre</b>",
      "code_insee": "08105",
      "internet": "VDSL",
      "densite": "Normale",
      "modele": "T300",
      "address": null,
      "timestamp": "2021-01-01",
      "lat": 4.719275,
      "lng": 49.760024,
      "id": 1,
      "hasShortAddress": false
     }  
 *
 * @param {*} options
 * @return {*}  {Promise<any>}
 * @memberof WifiPointsService
 */
getPoints(options:any): Promise<any> {

  console.log(options)
    return new Promise((resolve, reject) => {
      this.getAllPoints().then(d => {
        let offset = 0;
        if (options.offset) {
          offset = options.offset;
        }
        
        let r :any[] = MaFilter.FilterByConditions(options.where,d,options.sort);
        let counter = r.length;
        r.splice(offset+options.limit);
        r.splice(0,offset)
        resolve({rows:r,count:counter});
      })

    });
  }
}
