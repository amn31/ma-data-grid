import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Test1Component } from './pages/test1/test1.component';
import { MaDataGridModule } from '@amn31/ma-data-grid'
import { HttpClientModule } from '@angular/common/http';
import { CellUsageComponent } from './components/cell-usage/cell-usage.component';
import { Test2Component } from './pages/test2/test2.component';
import { Test3Component } from './pages/test3/test3.component';
import { Test4Component } from './pages/test4/test4.component';

@NgModule({
  declarations: [
    AppComponent,
    Test1Component,
    CellUsageComponent,
    Test2Component,
    Test3Component,
    Test4Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    // Ajouter par ALAIN
    HttpClientModule,
    MaDataGridModule,
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
