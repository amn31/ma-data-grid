import { Component, ComponentFactoryResolver, OnInit, Type } from '@angular/core';
import { MaDataGridCell } from '@amn31/ma-data-grid'

@Component({
  selector: 'app-cell-usage',
  template: `<div>
        <small> {{data.usage}}% </small>
        <div class="cell_usage" style="{{style}}">&nbsp;</div>

      </div>`,
  styleUrls: ['./cell-usage.component.css']
})
export class CellUsageComponent implements MaDataGridCell   {
  
  style: string = '';
  data: any;

  constructor() {
  }
  
  ngOnInit(): void {
    // console.log(this.data);
    this.style = "width: "+this.data.usage+'px;';
    if (this.data.usage > 90) {
      this.style += 'background-color: red';
    } else if (this.data.usage > 49) {
      this.style += 'background-color: #e69900';
    } else {
      this.style += 'background-color: #66ff33';
    }
  }

}
