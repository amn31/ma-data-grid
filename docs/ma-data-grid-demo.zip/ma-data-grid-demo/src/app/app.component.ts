import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  test: string = '';

  disabledButton(f) {
    if (this.test != f)
      return null;
    return 'disabled'
  }

  ngOnInit(): void {
    // console.log(window.location.search);
    if (window.location.search.match(/test4/)) {
      this.test = 'test4';
    } else if (window.location.search.match(/test2/)) {
      this.test = 'test2';
    } else if (window.location.search.match(/test3/)) {
      this.test = 'test3';
    } else {
      this.test = 'test1';
    }
  }

  title = 'ma-data-grid-demo';

}
