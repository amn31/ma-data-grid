import { FilterConditions, MaFilter } from '@amn31/filter-multiple-conditions';
import { Component, OnInit, ViewChild } from '@angular/core';
import { CellUsageComponent } from 'src/app/components/cell-usage/cell-usage.component';
import { WifiPointsService } from 'src/app/services/wifi-points.service';
import { MaDataGridColumnOptions, MaDataGridComponent, MaDataGridFilterEvent, MaDataGridHeadFilter, MaDataGridHeadFilterEvent, MaDataGridSelectEvent } from '@amn31/ma-data-grid'

@Component({
  selector: 'app-test2',
  templateUrl: './test2.component.html',
  styleUrls: ['./test2.component.css']
})
export class Test2Component implements OnInit {

  @ViewChild(MaDataGridComponent, { static: true }) datagrid: MaDataGridComponent;

  limit: number = 10;
  counter: number = 10;
  page: number = 0;
  rows: any;

  where: FilterConditions = null;
  sort: any;

  LoadError: string = '';

  /*
  {
    "emplacement": "Exterieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "geo_point_2d": [
      49.760024,
      4.719275
    ],
    "timestamp": "2019-05-06T22:45:36.503+02:00"
    "localisation": "HÔTEL DE VILLE MEZIERES 2",
    "liaison": "Cuivre",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T300",
    "address": "Place de l'Hôtel de Ville",
    "lat": 4.719275,
    "lng": 49.760024,
    "id": 1,
    "hasShortAddress": false
  }
  */

  columns: MaDataGridColumnOptions[] = [
    { prop: 'id', title: 'Id', sorted: true, dataType: 'number' },
    {
      prop: 'commune',
      title: 'City', sorted: true, dataType: 'string', cssClass: 'td_small',

      extFilter: true, extFilterSelected: true
    },
    {
      prop: 'usage', title: 'Usage', sorted: true, dataType: 'number',
      useTemplate: CellUsageComponent
    },
    { prop: 'isNew', title: 'New', extFilter: true, sorted: true, dataType: 'boolean' },
    { prop: 'lng', title: 'Lng', extFilter: true, sorted: true, dataType: 'number' },
    {
      prop: 'timestamp', title: 'Recorded', sorted: true,
      dataType: 'date'
    },
    {
      prop: 'liaison', title: 'Link', sorted: true,
      isRowHTML: true,
    },
    {
      prop: 'internet', title: 'Type', sorted: true,
      pipe: this.formatData
    },

    {
      prop: 'internet', title: 'Internet', sorted: true,
      headFilter: [{
        value: 'VDSL',
        operator: '=',
        label: 'vdsl'
      }, {
        value: 'ADSL',
        operator: '=',
        label: 'adsl'
      }]
    },
    //   
    { prop: 'modele', title: 'Model', sorted: true, extFilter: true, extFilterSelected: false }
  ];

  constructor(private wifiPointsService: WifiPointsService) { }

  ngOnInit() {
    console.log("ngOnInit");
    /* Initialize datas on start */
    this.loadPage(0);

    // Create header filters for 'Model' and 'Link'
    // according to datas found
    this.autoHeaderFilter('modele');
    this.autoHeaderFilter('liaison');
  }

  /**
   * Load data the current page according to parameters:
   * 
   *  page:    The current page to display
   *  limit:   Max number of rows to display in the datagrid
   *  where:   It's the where clause used according to the header Filter of the datagrid
   *           here the method updateFilter() will be used
   *  sort:    sort is used to sort the data according to that example of query {field: 'id', reverse: true}
   *
   * @param {*} page
   * @memberof Test2Component
   */
  loadPage(page) {

    console.log("this._loadPage()");
    this.wifiPointsService.getPoints({
      where: this.where,
      offset: page * this.limit,
      limit: this.limit,
      sort: this.sort // Example: {field: 'id', reverse: true}
    }).then((data: any) => {
      this.rows = data.rows;
      this.page = page;
      this.counter = data.count;
      console.log('loadPage DATA ============================= ', data);
    })

  }

  /**
   * Create options headFilter according to distinct values found in datas:
   * 
   *  this.columns.{field}.headFilter: [
   *    {
          value: {field_value},
          operator: '=',
          label: {fieldname}
        },
        ...
   *
   * @param {string} field
   * @memberof Test1Component
   */
  autoHeaderFilter(field: string) {


    this.wifiPointsService.getDistinctValues(field).then((values: any) => {
      console.log('MaDataGridHeadFilter ' + field, values);
      let d: MaDataGridHeadFilter[] = []
      values.forEach(element => {
        d.push({ value: element, operator: '=', label: element });
      });
      this.columns.find(elem => elem.prop === field).headFilter = d;
    })

  }

  /**
   * Field named 'Type' will be first letter of field value 'internet'
   *
   * @param {string} value
   * @param {any} row
   * @param {any} col
   * @return {*}  {string}
   * @memberof Test1Component
   */
  formatData(value, row: any, col): string {
    //console.log("formatData "+ row[col.prop], col)
    /*
    if (col.prop == 'internet' && 'ADSL' == value) {
      return '('+row['internet']+')';
    }*/
    if (value)
      return value.split('')[0];
  }

  SelectRowOrCell(event: MaDataGridSelectEvent) {
    console.log('SelectRowOrCell', event);
    setTimeout(() => {
      this.datagrid.resetSelection();
    }, 5000)
  }

  /**
   * When user uses head filter this method is called
   *
   * @param {MaDataGridHeadFilterEvent} event
   * @memberof Test2Component
   */
  updateFilter(event: MaDataGridHeadFilterEvent) {
    console.log('updateFilter', event.where);
    this.where = event.where;
    this.page = 0;
    this.loadPage(0);
  }
  
  /**
   * When user uses sort header this method is called
   *
   * @param {MaDataGridFilterEvent} event
   * @memberof Test2Component
   */
  sortBy(event: MaDataGridFilterEvent) {
    console.log('sortBy event', event);
    this.sort = event;
    this.loadPage(this.page);
  }

  /**
   * Fire event regarding the datagrid 
   *
   * @param {*} page
   * @memberof Test2Component
   */
  changePage(page) {
    console.log('changePage', page)
    this.loadPage(page);
  }

}
