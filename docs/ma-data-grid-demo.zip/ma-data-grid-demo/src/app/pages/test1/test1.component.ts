import { Component, OnInit, ViewChild } from '@angular/core';
import { MaDataGridColumnOptions, MaDataGridComponent, MaDataGridFilterEvent, MaDataGridHeadFilter, MaDataGridHeadFilterEvent, MaDataGridSelectEvent } from '@amn31/ma-data-grid'

import { CellUsageComponent } from 'src/app/components/cell-usage/cell-usage.component';
import { WifiPointsService } from 'src/app/services/wifi-points.service';
@Component({
  selector: 'app-test1',
  templateUrl: './test1.component.html',
  styleUrls: ['./test1.component.css']
})
export class Test1Component implements OnInit {

  @ViewChild(MaDataGridComponent, { static: true }) datagrid: MaDataGridComponent;

  limit: number = 10;
  rows: any;
  temp: any[];

  LoadError: string = '';

  /*
  {
    "emplacement": "Exterieur",
    "commune": "CHARLEVILLE-MEZIERES",
    "geo_point_2d": [
      49.760024,
      4.719275
    ],
    "timestamp": "2019-05-06T22:45:36.503+02:00"
    "localisation": "HÔTEL DE VILLE MEZIERES 2",
    "liaison": "Cuivre",
    "code_insee": "08105",
    "internet": "VDSL",
    "densite": "Normale",
    "modele": "T300",
    "address": "Place de l'Hôtel de Ville",
    "lat": 4.719275,
    "lng": 49.760024,
    "id": 1,
    "hasShortAddress": false
  }
  */

  columns: MaDataGridColumnOptions[] = [
    { prop: 'id', title: 'Id', sorted: true, dataType: 'number' },
    { prop: 'commune', 
      title: 'City', sorted: true, dataType: 'string', cssClass: 'td_small',
      
      extFilter: true, extFilterSelected: true },
    {
      prop: 'usage', title: 'Usage', sorted: true, dataType: 'number',
        useTemplate: CellUsageComponent
    },
    { prop: 'isNew', title: 'New', extFilter: true, sorted: true, dataType: 'boolean' },
    { prop: 'lng', title: 'Lng', extFilter: true, sorted: true, dataType: 'number' },
    {
      prop: 'timestamp', title: 'Recorded', sorted: true,
      dataType: 'date'
    },
    {
      prop: 'liaison', title: 'Link', sorted: true,
      isHTML: true,
    },
    {
      prop: 'internet', title: 'Type', sorted: true,
      pipe: this.formatData
    },

    {
      prop: 'internet', title: 'Internet', sorted: true,
      headFilter: [{
        value: 'VDSL',
        operator: '=',
        label: 'vdsl'
      }, {
        value: 'ADSL',
        operator: '=',
        label: 'adsl'
      }]
    },
    //   
    { prop: 'modele', title: 'Model', sorted: true, extFilter: true, extFilterSelected: false }
  ];

  constructor(private wifiPointsService: WifiPointsService) { }

  ngOnInit() {
    console.log("ngOnInit");
    /* Initialize datas once */
    this.loadPage();
  }

  loadPage() {

    console.log("this._loadPage()");
    this.LoadError = '';
    // Store data in this.temp and this.rows
    this.wifiPointsService.getAllPoints().then((data: []) => {
      this.temp = this.rows = data;
      console.log(data);
      // Create header filters for 'Model' and 'Link'
      // according to datas found
      this.autoHeaderFilter('modele');
      this.autoHeaderFilter('liaison');

    }).catch(err => {

    })

  }

  /**
   * Create options headFilter according to distinct values found in datas:
   * 
   *  this.columns.{field}.headFilter: [
   *    {
          value: {field_value},
          operator: '=',
          label: {fieldname}
        },
        ...
   *
   * @param {string} field
   * @memberof Test1Component
   */
  autoHeaderFilter(field: string) {


    this.wifiPointsService.getDistinctValues(field).then((values: any) => {
      console.log('MaDataGridHeadFilter ' + field, values);
      let d: MaDataGridHeadFilter[] = []
      values.forEach(element => {
        d.push({ value: element, operator: '=', label: element });
      });
      this.columns.find(elem => elem.prop === field).headFilter = d;
    })

  }

  /**
   * Field named 'Type' will be first letter of field value 'internet'
   *
   * @param {string} value
   * @param {any} row
   * @param {any} col
   * @return {*}  {string}
   * @memberof Test1Component
   */
  formatData(value, row:any, col): string {
    //console.log("formatData "+ row[col.prop], col)
    /*
    if (col.prop == 'internet' && 'ADSL' == value) {
      return '('+row['internet']+')';
    }*/
    if (value)
      return value.split('')[0];
  }

  SelectRowOrCell(event: MaDataGridSelectEvent) {
    console.log('SelectRowOrCell', event);
    setTimeout(() => {
      this.datagrid.resetSelection();
    }, 5000)
  }


  extUpdateFilter(event: MaDataGridFilterEvent) {
    //const val = event.target.value.toLowerCase();
    const val = event.text.toLowerCase();

    // filter our data
    const temp = this.temp.filter(function (d) {
      if (!val) {
        return true;
      }
      for (var f of event.fields) {
        if (d[f] && d[f].toLowerCase().indexOf(val) !== -1)
          return true;
      }
    });

    // update the rows
    this.rows = temp;
    console.log("DATA EXTERNAL FILTER ", this.rows)

  }

  updateFilter(event: MaDataGridHeadFilterEvent) {
    console.log('updateFilter', event.where);
    console.log("DATA HEADER FILTER", event.data)

  }

}
